import React, {Component} from "react";

export class Form extends Component{
    render(){
        return(
            <div className="formcon">
            <form action="/" method="post" id="Form">
            <div>
               
               <hr/>
                <table>
                    <tr>
                        <td>
                           <label className="fname" for="fname">First Name</label> 
                        </td>
                        <td>
                            <input type="text" id="fname" required/>   
                        </td>
                        <td>
                            <label for="lname" id="lname">Last Name</label>
                        </td>
                        <td>
                            <input type="text" id="lname" required/>
                        </td>
                        </tr> <br/>
                        <tr>
                            <td>
                                <label for="email">Email</label>
                            </td>
                            <td>
                                <input type="text" id="email"/>
                            </td>
                        </tr> <br/>
                        <tr>
                            <td>
                                <label for="gender">Gender</label>
                            </td>
                            <td>
                                <input type="radio" id="Gender" name="Gender" value="1" onclick="checkedOnClick(this);"/>Male <br/>
                                <input type="radio" id="Gender" name="Gender" value="2" onclick="checkedOnClick(this);"/>Female <br/>
                                <input type="radio" id="Gender" name="Gender" value="3" onclick="checkedOnClick(this);"/>Others <br/>
                            </td> 
                        </tr> <br/>
                        <tr>
                            <td>
                                <label for="room">Room Type</label>
                            </td>
                            <td>
                                <input type="text" id="room" required/>
                            </td>
                        </tr> <br/>
                        <tr>
                            <td>
                                <label for="guests">No Of Guests</label>
                            </td>
                            <td>
                                <input type="number" id="guests"/>
                            </td>
                        </tr> <br/>
                        <tr>
                            <td>
                                <label for="bookf">Booking From</label>
                            </td>
                            <td>
                                <input type="date" id="bookingf"/>
                            </td>
                        </tr> <br/>
                        <tr>
                            <td>
                                <label for="bookt">Booking To</label>
                            </td>
                            <td>
                                <input type="date" id="bookt"/>
                            </td>
                        </tr> <br/>
                        <tr>
                            <td>
                                <label for="pickup">Free Pickup</label>
                            </td>
                            <td>
                                <select name="pickup" id="pickup">
                                    <option value="1">-SELECT-</option>
                                    <option value="2">Yes Please</option>
                                    <option value="3">No Thanks</option>
                                </select>
                            </td>
                        </tr> <br/>
                        <tr>
                            <td>
                                <label for="facility">Facilities Required</label>
                            </td>
                            <td>
                                <input type="checkbox" name="Wifi"/>Wifi 
                                <input type="checkbox" name="AC"/> AC
                                <input type="checkbox" name="TV"/>TV
                            </td>
                        </tr> <br/>
                        <tr>
                            <td>
                                <label for="food">Food Required</label>
                            </td>
                            <td>
                                <input type="radio" name="Food" onclick="checkedOnClick(this);"/>Yes
                                <input type="radio" name="Food" onclick="checkedOnClick(this);"/>No
                            </td>
                        </tr> <br/>
                        <tr>
                            <td>
                                <label for="address">Address</label>
                            </td>
                            <td>
                                <input type="text" id="address1" placeholder="street address" required/> <br/>
                                <input type="text" id="address2" placeholder="street address2"/> <br/>
                                <input type="number" id="zipcode" placeholder="zipcode" maxLength="6" required/> <br/>
                            </td>
                        </tr> <br/>
                        <tr>
                            <td>
                                <label for="country">Country</label>
                            </td>
                            <td>
                                <input type="text" id="country" required/>
                            </td>
                        </tr> <br/>
                        <tr>
                            <td>
                                <label for="province">Province</label>
                            </td>
                            <td>
                                <input type="text" id="province" required/>
                            </td>
                        </tr> <br/>
                        <tr>
                            <td>
                                <label for="phone">Phone Number</label>
                            </td>
                            <td>
                                <input type="number" id="phone" maxLength="10" required/>
                            </td>
                        </tr> <br/>
                        <tr>
                            <td>
                                <label for="request">Special Request</label>
                            </td>
                            <td>
                                <input type="text" id="req" maxLength="250"/>
                            </td>
                        </tr> <br/>
                </table>
            <div>
                <button type="Submit">Submit</button>
                <button type="Cancel">Cancel</button>
                <button type="BookingList">Booking List</button>
            </div>
            </div>
            </form>
            </div>
        )
    }
}

export default Form;