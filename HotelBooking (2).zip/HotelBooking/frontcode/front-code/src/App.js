import logo from './logo.svg';
import './App.css';
import Form from './Components/Form';

function App() {
  return (
    <div className="App">
      <h1>Hotel Booking</h1>
      <Form />
    </div>
  );
}

export default App;
