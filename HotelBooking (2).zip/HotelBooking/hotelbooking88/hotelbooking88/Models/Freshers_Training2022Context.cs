﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace hotelbooking88.Models
{
    public partial class Freshers_Training2022Context : DbContext
    {
        public Freshers_Training2022Context()
        {
        }

        public Freshers_Training2022Context(DbContextOptions<Freshers_Training2022Context> options)
            : base(options)
        {
        }

        public virtual DbSet<YagAddress> YagAddress { get; set; }
        public virtual DbSet<YagFacilities> YagFacilities { get; set; }
        public virtual DbSet<YagRoomType> YagRoomType { get; set; }
        public virtual DbSet<YagneshHotel> YagneshHotel { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=192.168.1.230;Initial Catalog=Freshers_Training2022;Persist Security Info=True;User ID=trainee2022;Password=trainee@2022");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<YagAddress>(entity =>
            {
                entity.HasKey(e => e.AddressId)
                    .HasName("PK__YagAddre__0382FFC2CA3224DB");

                entity.Property(e => e.AddressId)
                    .HasColumnName("Address_id")
                    .ValueGeneratedNever();

                entity.Property(e => e.Country)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.Province)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdNavigation)
                    .WithMany(p => p.YagAddress)
                    .HasForeignKey(d => d.Id)
                    .HasConstraintName("FK__YagAddress__Id__0C477DD9");
            });

            modelBuilder.Entity<YagFacilities>(entity =>
            {
                entity.HasKey(e => e.FacId)
                    .HasName("PK__YagFacil__815081E8D1562C9C");

                entity.Property(e => e.FacId).ValueGeneratedNever();

                entity.Property(e => e.Facility)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdNavigation)
                    .WithMany(p => p.YagFacilities)
                    .HasForeignKey(d => d.Id)
                    .HasConstraintName("FK__YagFacilitie__Id__096B112E");
            });

            modelBuilder.Entity<YagRoomType>(entity =>
            {
                entity.HasKey(e => e.RoomId)
                    .HasName("PK__YagRoomT__32863939DF51FF1F");

                entity.Property(e => e.RoomId).ValueGeneratedNever();

                entity.Property(e => e.RoomType)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.HasOne(d => d.IdNavigation)
                    .WithMany(p => p.YagRoomType)
                    .HasForeignKey(d => d.Id)
                    .HasConstraintName("FK__YagRoomType__Id__068EA483");
            });

            modelBuilder.Entity<YagneshHotel>(entity =>
            {
                entity.Property(e => e.BookingFrom).HasColumnType("date");

                entity.Property(e => e.BookingTo).HasColumnType("date");

                entity.Property(e => e.Email)
                    .HasMaxLength(319)
                    .IsUnicode(false);

                entity.Property(e => e.FirstName)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.FoodReq)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.FreePickup)
                    .HasMaxLength(15)
                    .IsUnicode(false);

                entity.Property(e => e.Gender)
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.LastName)
                    .HasMaxLength(25)
                    .IsUnicode(false);

                entity.Property(e => e.SpeacialRequest)
                    .HasMaxLength(250)
                    .IsUnicode(false);

                entity.Property(e => e.StreetAddress)
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.StreetAddress2)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
