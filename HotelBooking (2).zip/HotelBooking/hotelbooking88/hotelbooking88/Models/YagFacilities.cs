﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace hotelbooking88.Models
{
    public partial class YagFacilities
    {
        public int FacId { get; set; }
        public string Facility { get; set; }
        public int? Id { get; set; }

        public virtual YagneshHotel IdNavigation { get; set; }
    }
}
