﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace hotelbooking88.Models
{
    public partial class YagAddress
    {
        public int AddressId { get; set; }
        public int? ZipCode { get; set; }
        public string Province { get; set; }
        public string Country { get; set; }
        public int? Id { get; set; }

        public virtual YagneshHotel IdNavigation { get; set; }
    }
}
