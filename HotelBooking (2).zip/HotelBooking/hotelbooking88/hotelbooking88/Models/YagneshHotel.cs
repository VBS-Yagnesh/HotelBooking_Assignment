﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace hotelbooking88.Models
{
    public partial class YagneshHotel
    {
        public YagneshHotel()
        {
            YagAddress = new HashSet<YagAddress>();
            YagFacilities = new HashSet<YagFacilities>();
            YagRoomType = new HashSet<YagRoomType>();
        }

        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Gender { get; set; }
        public int? NoOfGuest { get; set; }
        public DateTime? BookingFrom { get; set; }
        public DateTime? BookingTo { get; set; }
        public string FreePickup { get; set; }
        public string FoodReq { get; set; }
        public string StreetAddress { get; set; }
        public string StreetAddress2 { get; set; }
        public string SpeacialRequest { get; set; }
        public int? PhoneNumber { get; set; }

        public virtual ICollection<YagAddress> YagAddress { get; set; }
        public virtual ICollection<YagFacilities> YagFacilities { get; set; }
        public virtual ICollection<YagRoomType> YagRoomType { get; set; }
    }
}
