﻿using hotelbooking88.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace hotelbooking88.Controllers
{
    //[Route("api/[controller]")]
    [ApiController]
    public class MainController : ControllerBase
    {

        private Freshers_Training2022Context _context;

        public MainController(Freshers_Training2022Context context)
        {
            _context = context;


    //  **************** For YagneshHotel Model *****************************
        }
        [Route("api/[controller]/YagneshHotel")]
        [HttpGet] // To get the list of all Customers
        public IEnumerable<YagneshHotel> Get()
        {
            return _context.YagneshHotel.ToList();
        }
        [Route("api/[controller]/YagneshHotel")]
        [HttpGet("{id}")] //To get customers on the basis of Id
        public YagneshHotel GetData(int id)
        {
            var det = _context.YagneshHotel.Where(x => x.Id == id).FirstOrDefault();
            return det;
        }
        [Route("api/[controller]/YagneshHotel")]
        [HttpPost]
        public IActionResult Post([FromBody] YagneshHotel hot)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid Model");
            }
            _context.YagneshHotel.Add(hot);
            _context.SaveChanges();
            return Ok();
        }
        [Route("api/[controller]/YagneshHotel")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Put([FromBody] YagneshHotel hot, int id)
        {

            if (id != hot.Id)
            {
                return BadRequest("Id not valid");
            }
            var Hotel = await _context.YagneshHotel.FindAsync(id);
            if (Hotel != null)
            {
                Hotel.Id = hot.Id;
                Hotel.FirstName = hot.FirstName;
                Hotel.LastName = hot.LastName;
                Hotel.Email = hot.Email;
                Hotel.Gender = hot.Gender;
                Hotel.PhoneNumber = hot.PhoneNumber;
                Hotel.NoOfGuest = hot.NoOfGuest;
                Hotel.BookingFrom = hot.BookingFrom;
                Hotel.BookingTo = hot.BookingTo;
                Hotel.FreePickup = hot.FreePickup;
                Hotel.FoodReq = hot.FoodReq;
                Hotel.StreetAddress = hot.StreetAddress;
                Hotel.StreetAddress2 = hot.StreetAddress2;
                Hotel.SpeacialRequest = hot.SpeacialRequest;
                await _context.SaveChangesAsync();
                return Ok();
            }
            else
            {
                return NoContent(); // Produces empty status code
            }
        }
        [Route("api/[controller]/YagneshHotel")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var dett = await _context.YagneshHotel.FindAsync(id);
            if (dett == null)
            {
                return NoContent();
            }
            _context.YagneshHotel.Remove(dett);
            await _context.SaveChangesAsync();
            return NoContent();
        }



        // ************ For YagAddress *********************

        [Route("api/[controller]/YagAddress")]
        [HttpGet] // To get the list of all Customers
        public IEnumerable<YagAddress> Get2()
        {
            return _context.YagAddress.ToList();
        }
        [Route("api/[controller]/YagAddress")]
        [HttpGet("{id}")] //To get customers on the basis of Id
        public YagAddress GetData2(int id)
        {
            var det = _context.YagAddress.Where(x => x.AddressId == id).FirstOrDefault();
            return det;
        }
        [HttpPost]
        [Route("api/[controller]/YagAddress")]
        public IActionResult Post([FromBody] YagAddress hot)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid Model");
            }
            _context.YagAddress.Add(hot);
            _context.SaveChanges();
            return Ok();
        }
        [HttpPut("{id}")]
        [Route("api/[controller]/YagAddress")]
        public async Task<IActionResult> Put([FromBody] YagAddress hot, int id)
        {

            if (id != hot.Id)
            {
                return BadRequest("Id not valid");
            }
            var Hotel = await _context.YagAddress.FindAsync(id);
            if (Hotel != null)
            {
                Hotel.AddressId = hot.AddressId;                
                Hotel.ZipCode = hot.ZipCode;
                Hotel.Province = hot.Province;
                Hotel.Country = hot.Country;
                Hotel.Id = hot.Id;
                await _context.SaveChangesAsync();
                return Ok();
            }
            else
            {
                return NoContent(); // Produces empty status code
            }
        }

        [HttpDelete("{id}")]
        [Route("api/[controller]/YagAddress")]
        public async Task<IActionResult> Delete2(int id)
        {
            var dett = await _context.YagAddress.FindAsync(id);
            if (dett == null)
            {
                return NoContent();
            }
            _context.YagAddress.Remove(dett);
            await _context.SaveChangesAsync();
            return NoContent();
        }



        // ************************* For YagFacilities ****************************


        [Route("api/[controller]/YagFacilities")]
        [HttpGet] // To get the list of all Customers
        public IEnumerable<YagFacilities> Get3()
        {
            return _context.YagFacilities.ToList();
        }
        [Route("api/[controller]/YagFacilities")]
        [HttpGet("{id}")] //To get customers on the basis of Id
        public YagFacilities GetData3(int id)
        {
            var fac = _context.YagFacilities.Where(x => x.FacId == id).FirstOrDefault();
            return fac;
        }
        [Route("api/[controller]/YagFacilities")]
        [HttpPost]
        public IActionResult Post([FromBody] YagFacilities hot)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid Model");
            }
            _context.YagFacilities.Add(hot);
            _context.SaveChanges();
            return Ok();
        }
        [Route("api/[controller]/YagFacilities")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Put([FromBody] YagFacilities hot, int id)
        {

            if (id != hot.Id)
            {
                return BadRequest("Id not valid");
            }
            var Hotel = await _context.YagFacilities.FindAsync(id);
            if (Hotel != null)
            {
                Hotel.FacId = hot.FacId;
                Hotel.Facility = hot.Facility;
                Hotel.Id = hot.Id;
                await _context.SaveChangesAsync();
                return Ok();
            }
            else
            {
                return NoContent(); // Produces empty status code
            }
        }
        [Route("api/[controller]/YagFacilities")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete3(int id)
        {
            var dett = await _context.YagFacilities.FindAsync(id);
            if (dett == null)
            {
                return NoContent();
            }
            _context.YagFacilities.Remove(dett);
            await _context.SaveChangesAsync();
            return NoContent();
        }




        // ******************************** For YagRoomType *****************************************

        [Route("api/[controller]/YagRoomType")]
        [HttpGet] // To get the list of all Customers
        public IEnumerable<YagRoomType> Get4()
        {
            return _context.YagRoomType.ToList();
        }
        [Route("api/[controller]/YagRoomType")]
        [HttpGet("{id}")] //To get customers on the basis of Id
        public YagRoomType GetData4(int id)
        {
            var fac = _context.YagRoomType.Where(x => x.RoomId == id).FirstOrDefault();
            return fac;
        }
        [Route("api/[controller]/YagRoomType")]
        [HttpPost]
        public IActionResult Post([FromBody] YagRoomType hot)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest("Invalid Model");
            }
            _context.YagRoomType.Add(hot);
            _context.SaveChanges();
            return Ok();
        }
        [Route("api/[controller]/YagRoomType")]
        [HttpPut("{id}")]
        public async Task<IActionResult> Put([FromBody] YagRoomType hot, int id)
        {

            if (id != hot.Id)
            {
                return BadRequest("Id not valid");
            }
            var Hotel = await _context.YagRoomType.FindAsync(id);
            if (Hotel != null)
            {
                Hotel.RoomId = hot.RoomId;
                Hotel.RoomType = hot.RoomType;
                Hotel.Id = hot.Id;
                await _context.SaveChangesAsync();
                return Ok();
            }
            else
            {
                return NoContent(); // Produces empty status code
            }
        }
        [Route("api/[controller]/YagRoomType")]
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete4(int id)
        {
            var dett = await _context.YagRoomType.FindAsync(id);
            if (dett == null)
            {
                return NoContent();
            }
            _context.YagRoomType.Remove(dett);
            await _context.SaveChangesAsync();
            return NoContent();
        }
    }

}
